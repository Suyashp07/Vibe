import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import {
  sendTelegramMessage,
  editTelegramMessage,
  answerTelegramCallback,
  downloadTelegramFileBuffer,
  approveChatJoinRequest,
  declineChatJoinRequest,
} from '@/lib/telegram';
import {
  extractEventFromImage,
  extractEventFromText,
  scrapeUrlMetadata,
  getCategoryCover,
  detectCategoryFromText,
  ExtractedEventData,
} from '@/lib/ai/eventExtractor';
import { calculateEventSurety } from '@/lib/eventSurety';
import { checkDuplicateEventInDb } from '@/lib/aggregation/dedup';
import { nanoid } from 'nanoid';
import { telegramAdapter } from '@/lib/communication/adapters/telegramAdapter';
import { conversationService } from '@/lib/communication/conversationService';
import { ADMIN_BASE_PATH } from '@/lib/adminConstants';

export const dynamic = 'force-dynamic';

function getSupabaseAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
  const key =
    process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
  return createClient(url, key, { auth: { persistSession: false } });
}

function getAppUrl(req?: Request): string {
  if (req) {
    const host = req.headers.get('x-forwarded-host') || req.headers.get('host');
    if (host && !host.includes('localhost') && !host.includes('127.0.0.1')) {
      const proto = req.headers.get('x-forwarded-proto') || 'https';
      return `${proto}://${host}`;
    }
  }

  const envUrl = process.env.NEXT_PUBLIC_APP_URL || '';
  if (envUrl && !envUrl.includes('localhost') && !envUrl.includes('127.0.0.1')) {
    return envUrl.replace(/\/$/, '');
  }

  return 'https://vibe.swaniki.com';
}

export async function GET() {
  return NextResponse.json({
    ok: true,
    service: 'Vibe Telegram Ingestion Webhook',
    timestamp: new Date().toISOString(),
  });
}

export async function POST(req: NextRequest) {
  let update: any = null;
  try {
    // 0. Verify Telegram Webhook Secret Token if configured (Security Requirement 11)
    if (!telegramAdapter.verifyWebhook(req)) {
      console.warn('[Telegram Webhook] Unauthorized webhook request: token mismatch');
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    update = await req.json();

    // 1. Handle Inline Button Callback Queries (Approve / Discard)
    if (update.callback_query) {
      const cq = update.callback_query;
      const senderId = cq.from.id;
      const chatId = cq.message.chat.id;
      const messageId = cq.message.message_id;
      const data = cq.data || '';

      const supabase = getSupabaseAdmin();
      const appUrl = getAppUrl(req);

      if (data.startsWith('publish:') || data.startsWith('publish_instant:')) {
        const eventId = data.replace(/^publish(_instant)?:/, '');
        const { data: updatedEvent, error } = await supabase
          .from('events')
          .update({
            status: 'live',
            is_public: true,
            source_platform: 'telegram',
            updated_at: new Date().toISOString(),
          })
          .eq('id', eventId)
          .select('id, title, slug, start_at, location_name')
          .single();

        if (error || !updatedEvent) {
          await answerTelegramCallback(cq.id, 'Failed to publish event', true);
          return NextResponse.json({ ok: true });
        }

        await answerTelegramCallback(cq.id, '⚡ Published to Vibe Instant!');

        const eventUrl = `${appUrl}/${updatedEvent.slug}`;
        const instantLink = `${appUrl}/vibes?event=${updatedEvent.slug}`;
        const publishedText = `⚡ <b>EVENT IS LIVE ON VIBE!</b>\n\n` +
          `📌 <b>${updatedEvent.title}</b>\n` +
          `📍 ${updatedEvent.location_name}\n\n` +
          `🔗 <b>ACTUAL EVENT LINK:</b>\n<a href="${eventUrl}">${eventUrl}</a>\n\n` +
          `📱 <b>Vibe Instant Reel:</b>\n<a href="${instantLink}">${instantLink}</a>\n\n` +
          `📋 <b>Tap to copy link:</b> <code>${eventUrl}</code>\n\n` +
          `<i>Guests can RSVP & view tickets directly on Vibe!</i>`;

        await editTelegramMessage(chatId, messageId, publishedText, {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🌐 Open Event Link ↗', url: eventUrl }],
              [{ text: '⚡ View in Vibe Instant ↗', url: instantLink }],
            ],
          },
        });

        return NextResponse.json({ ok: true });
      }

      if (data.startsWith('discard:')) {
        const eventId = data.replace('discard:', '');
        await supabase.from('events').delete().eq('id', eventId);
        await answerTelegramCallback(cq.id, 'Event discarded');
        await editTelegramMessage(chatId, messageId, '❌ <b>Event draft discarded.</b>', {
          parse_mode: 'HTML',
        });
        return NextResponse.json({ ok: true });
      }

      if (data.startsWith('admit_guest:')) {
        const parts = data.replace('admit_guest:', '').split(':');
        const targetUserId = Number(parts[0]);
        const targetChatId = parts[1] || chatId;

        const approved = await approveChatJoinRequest(targetChatId, targetUserId);
        await answerTelegramCallback(cq.id, approved ? '✅ Guest admitted to event chat!' : 'Failed to admit guest');
        await editTelegramMessage(
          chatId,
          messageId,
          `${cq.message.text}\n\n✅ <b>ADMITTED by host</b>`,
          { parse_mode: 'HTML' }
        );
        return NextResponse.json({ ok: true });
      }

      if (data.startsWith('reject_guest:')) {
        const parts = data.replace('reject_guest:', '').split(':');
        const targetUserId = Number(parts[0]);
        const targetChatId = parts[1] || chatId;

        await declineChatJoinRequest(targetChatId, targetUserId);
        await answerTelegramCallback(cq.id, '❌ Guest admission declined');
        await editTelegramMessage(
          chatId,
          messageId,
          `${cq.message.text}\n\n❌ <b>DECLINED by host</b>`,
          { parse_mode: 'HTML' }
        );
        return NextResponse.json({ ok: true });
      }

      if (data.startsWith('copy:')) {
        await answerTelegramCallback(cq.id, 'Link ready to share!');
        return NextResponse.json({ ok: true });
      }

      return NextResponse.json({ ok: true });
    }

    // 1B. Handle Native Telegram Chat Join Requests (creates_join_request=True anti-scam gate)
    if (update.chat_join_request) {
      const cjr = update.chat_join_request;
      const targetChatId = cjr.chat.id;
      const user = cjr.from;
      const userId = user.id;
      const userFullName = [user.first_name, user.last_name].filter(Boolean).join(' ');
      const username = user.username ? `@${user.username}` : userFullName;

      console.log('[Telegram Webhook] Received Chat Join Request:', {
        targetChatId,
        userId,
        username,
      });

      // Send admission prompt with 1-click Approve / Reject buttons
      await sendTelegramMessage(
        targetChatId,
        `🛡️ <b>New Group Admission Request</b>\n\n👤 <b>Attendee:</b> ${userFullName} (${username})\n🆔 <b>User ID:</b> <code>${userId}</code>\n\n<i>Host, do you approve this attendee joining the event group?</i>`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '✅ Approve Entry', callback_data: `admit_guest:${userId}:${targetChatId}` },
                { text: '❌ Reject', callback_data: `reject_guest:${userId}:${targetChatId}` },
              ],
            ],
          },
        }
      );

      return NextResponse.json({ ok: true, handled: 'chat_join_request' });
    }

    // 2. Handle Incoming Messages
    if (!update.message) {
      return NextResponse.json({ ok: true });
    }

    if (update.message.from?.is_bot) {
      return NextResponse.json({ ok: true });
    }

    // 2A. Communication Gateway Interception (Host Replies from Telegram Topic)
    const incomingHostMsg = await telegramAdapter.processIncomingMessage(update);
    if (incomingHostMsg) {
      // 2A.1 Handle duplicate webhook deliveries safely
      if (incomingHostMsg.isDuplicate) {
        return NextResponse.json({ ok: true, duplicate: true });
      }

      let conv = null;
      if (incomingHostMsg.conversationId) {
        conv = await conversationService.getConversationById(incomingHostMsg.conversationId);
      }
      if (!conv && incomingHostMsg.telegramTopicId) {
        conv = await conversationService.resolveConversationByTopic(
          incomingHostMsg.telegramTopicId,
          incomingHostMsg.telegramChatId
        );
      }

      // 2A.2 Exact mapping matched
      if (conv) {
        if (conv.status === 'CLOSED') {
          console.warn('[Telegram Webhook] Host attempted reply on closed conversation:', conv.id);
          return NextResponse.json({
            ok: true,
            warning: 'Conversation is closed',
            conversationId: conv.id,
          });
        }

        const savedMsg = await conversationService.postHostMessage({
          conversationId: conv.id,
          senderId: incomingHostMsg.senderId || 'telegram-host',
          content: incomingHostMsg.messageContent,
          channel: 'TELEGRAM',
          externalMessageId: incomingHostMsg.externalMessageId,
        });

        console.log('[Telegram Webhook] Host message routed to Vibe conversation:', {
          conversationId: conv.id,
          messageId: savedMsg.id,
          topicId: incomingHostMsg.telegramTopicId,
          chatId: incomingHostMsg.telegramChatId,
        });

        return NextResponse.json({
          ok: true,
          handledBy: 'communication_gateway',
          conversationId: conv.id,
          messageId: savedMsg.id,
        });
      }

      // 2A.3 Unmapped topic handling: Let message fall through to Event Creation flow
      if (incomingHostMsg.telegramTopicId || incomingHostMsg.isUnmapped) {
        console.log('[Telegram Webhook] Unmapped topic message, proceeding to AI Event Creation flow:', {
          chatId: incomingHostMsg.telegramChatId,
          topicId: incomingHostMsg.telegramTopicId,
        });
      }
    }

    // 3. Existing Event Flyer / Link Submission Ingestion Flow
    const message = update.message;
    const chatId = message.chat.id;
    const senderId = message.from.id;
    const threadId = message.message_thread_id;

    const replyTelegram = (text: string, options?: any) =>
      sendTelegramMessage(chatId, text, {
        ...options,
        ...(threadId ? { message_thread_id: threadId } : {}),
      });

    // Every user is authorized to submit events through Telegram bot
    // Handle /start or /help command
    const textContent = message.text || message.caption || '';
    const lowerText = textContent.toLowerCase();
    const cleanLowerText = lowerText.trim();
    const isBareCommand =
      /^(?:\/newevent|\/new|\/create|\/add|\/event|\/vibe|\/flash|new event|create event|add event|make event|create an event|make an event|host an event|host event|post event|post an event|event|new meetup|create meetup|vibe|flash|test|testing|vibe\/events|vibes\/events|vibe events|events)$/i.test(cleanLowerText);

    if (
      lowerText.startsWith('/start') ||
      lowerText.startsWith('/help') ||
      lowerText === 'hi' ||
      lowerText.includes('vibe_events') ||
      cleanLowerText === 'vibe/events'
    ) {
      const welcome =
        `👋 <b>Welcome to Vibe Assistant (@VibeCurator_bot)!</b>\n\n` +
        `Ready to post your <b>Vibe or Event</b>? Here's how:\n\n` +
        `⚡ <b>Post a Vibe Instant:</b> Send details (e.g. <i>"Box cricket at Bandra Turf tonight 8 PM. Need 4 players"</i>) to post immediately live to the <b>Vibe Instant</b> stream!\n` +
        `📸 <b>Host an Event:</b> Forward or send any event flyer photo or poster.\n` +
        `🔗 <b>Import from Link:</b> Send any link from BookMyShow, Luma, District, or Unstop.\n` +
        `💬 <b>Custom Details:</b> Send event name, date, time, and venue!\n\n` +
        `<i>Just send your details or flyer photo right here to get started! 🚀</i>`;
      await replyTelegram(welcome, { parse_mode: 'HTML' });
      return NextResponse.json({ ok: true });
    }

    if (isBareCommand) {
      const guidance =
        `✨ <b>Ready to create an event on Vibe?</b>\n\n` +
        `Please send me your event details in any format:\n\n` +
        `• <b>Event Name:</b> (e.g. <i>Sunset Acoustic Jam</i>)\n` +
        `• <b>Date & Time:</b> (e.g. <i>Tomorrow 7:30 PM</i>)\n` +
        `• <b>Venue & City:</b> (e.g. <i>Subko Cafe, Bandra, Mumbai</i>)\n` +
        `• <b>Ticketing:</b> (e.g. <i>Free Entry / ₹499</i>)\n\n` +
        `<i>Or simply:</i>\n` +
        `📸 <b>Send a flyer photo</b> or poster\n` +
        `🔗 <b>Send an event link</b> from BookMyShow, Luma, District, or Unstop!`;
      await replyTelegram(guidance, { parse_mode: 'HTML' });
      return NextResponse.json({ ok: true });
    }

    // Check for Flyer Image or Flash Vibe intent
    const isPhoto = Boolean(message.photo && message.photo.length > 0);
    const isImageDoc = Boolean(message.document && message.document.mime_type?.startsWith('image/'));
    const hasExternalLink = Boolean(textContent.match(/https?:\/\/[^\s]+/i));

    const isFlashVibe =
      (lowerText.startsWith('/vibe') ||
      lowerText.startsWith('/flash') ||
      lowerText.startsWith('vibe:') ||
      lowerText.startsWith('flash:') ||
      lowerText.startsWith('⚡') ||
      /\b(cricket|match|play|badminton|pickleball|football|turf|chai|coffee|cafe|tea|midnight chai|casual meetup|pickup game|anyone up for|looking for \d+ players|quick meetup|to play|to meetup|hangout|jam|jamming|acoustic|board games?|chess|poker|potluck|pub crawl|walk|sprint|coworking|cycling|running|jogging)\b/i.test(textContent)) &&
      !isPhoto &&
      !hasExternalLink;

    let flashActivity: string = 'other';
    if (/\b(cricket|box cricket|gully cricket|match|batting|bowling)\b/i.test(textContent)) flashActivity = 'cricket';
    else if (/\b(badminton|shuttle)\b/i.test(textContent)) flashActivity = 'badminton';
    else if (/\b(pickleball|paddle|pickle|picklebot|pickle bot|dink|dinking)\b/i.test(textContent)) flashActivity = 'pickleball';
    else if (/\b(football|futsal|soccer)\b/i.test(textContent)) flashActivity = 'football';
    else if (/\b(chai|coffee|cafe|tea)\b/i.test(textContent)) flashActivity = 'coffee';
    else if (/\b(board games?|catan|chess|poker)\b/i.test(textContent)) flashActivity = 'games';
    else if (/\b(jam|acoustic|guitar|music|singing)\b/i.test(textContent)) flashActivity = 'music';
    else if (/\b(sprint|code|hack|hackathon|laptop|work|coworking)\b/i.test(textContent)) flashActivity = 'sprint';

    const supabase = getSupabaseAdmin();
    let extracted: ExtractedEventData;
    let coverImageUrl = getCategoryCover('default');

    // First reply immediately confirming AI is creating the event
    await replyTelegram(
      '🤖 <b>AI is making your event...</b> Please wait a moment while I set everything up! ⚡',
      { parse_mode: 'HTML' }
    );

    // CASE A: Flyer Image Provided (as Photo or Document file)
    if (isPhoto || isImageDoc) {
      const fileId = isPhoto
        ? message.photo[message.photo.length - 1].file_id
        : message.document.file_id;

      const { buffer, mimeType } = await downloadTelegramFileBuffer(fileId);

      // Attempt upload to Supabase Storage bucket 'event-covers'
      try {
        const fileExt = mimeType.includes('png') ? 'png' : 'jpg';
        const fileName = `telegram-${Date.now()}-${nanoid(6)}.${fileExt}`;
        const filePath = `covers/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('event-covers')
          .upload(filePath, buffer, {
            contentType: mimeType,
            upsert: true,
          });

        if (!uploadError) {
          const { data: publicUrlData } = supabase.storage
            .from('event-covers')
            .getPublicUrl(filePath);
          coverImageUrl = publicUrlData.publicUrl;
        } else {
          console.warn('[Telegram Webhook] Storage upload warning:', uploadError.message);
        }
      } catch (err) {
        console.warn('[Telegram Webhook] Storage upload failed, using fallback:', err);
      }

      // Extract details via Gemini Vision
      extracted = await extractEventFromImage(buffer, mimeType, message.caption);

      // If caption contains an external URL, scrape it to enrich price and ticketing link
      if (message.caption) {
        const captionUrlMatch = message.caption.match(/(https?:\/\/[^\s]+)/i);
        if (captionUrlMatch) {
          const captionUrl = captionUrlMatch[1].trim();
          try {
            const scraped = await scrapeUrlMetadata(captionUrl);
            if (scraped.price) {
              extracted.price_text = scraped.price;
            }
            if (!extracted.ticket_url) {
              extracted.ticket_url = captionUrl;
            }
            if (scraped.platform && scraped.platform !== 'telegram') {
              extracted.source_platform = scraped.platform;
            }
          } catch (e) {
            console.warn('[Telegram Webhook] Scrape caption URL failed:', e);
          }
        }
      }
    }
    // CASE B: Text / Link Provided
    else if (message.text) {
      extracted = await extractEventFromText(message.text);
      // Pick suitable cover photo:
      // 1. Scraped OpenGraph image if user provided an event link
      // 2. Curated editorial high-res photography matching event category & title
      const finalCategory = extracted.category || detectCategoryFromText(`${extracted.title} ${message.text}`);
      coverImageUrl =
        extracted.cover_image_url ||
        getCategoryCover(finalCategory, extracted.title);
    } else {
      await replyTelegram(
        '⚠️ Please send an event flyer photo, an event URL, or a text description.',
        { parse_mode: 'HTML' }
      );
      return NextResponse.json({ ok: true });
    }

    // Validate timestamps safely for PostgreSQL timestamptz in IST (+05:30)
    let validStartAt = new Date(Date.now() + 86400000).toISOString();
    try {
      if (extracted.start_at) {
        let rawStart = String(extracted.start_at).trim();
        // If string has date and time without explicit timezone (e.g. "2026-11-26T21:00:00" without Z or +), append +05:30
        if (/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2})?$/.test(rawStart)) {
          rawStart = rawStart.replace(' ', 'T') + '+05:30';
        }
        if (!isNaN(new Date(rawStart).getTime())) {
          validStartAt = new Date(rawStart).toISOString();
        }
      }
    } catch {}

    let validEndAt = new Date(new Date(validStartAt).getTime() + 10800000).toISOString();
    try {
      if (extracted.end_at) {
        let rawEnd = String(extracted.end_at).trim();
        if (/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2})?$/.test(rawEnd)) {
          rawEnd = rawEnd.replace(' ', 'T') + '+05:30';
        }
        if (!isNaN(new Date(rawEnd).getTime())) {
          validEndAt = new Date(rawEnd).toISOString();
        }
      }
    } catch {}

    // Ensure valid slug uniqueness
    const finalSlug = `${extracted.suggested_slug}-${nanoid(4)}`;

    // Format theme configuration
    const themeConfig = {
      palette: extracted.template === 'ember' ? 'sunset' : 'forest',
      font: 'Inter + Fraunces',
      bg_style: 'texture',
      button_style: 'solid',
    };

    const detectedCity = extracted.city || 'Pune';

    // Determine whether this is a native Vibe event or an external aggregated event
    const rawTicketUrl = extracted.ticket_url?.trim();
    const normalizedTicketUrl = rawTicketUrl
      ? (rawTicketUrl.startsWith('http://') || rawTicketUrl.startsWith('https://') ? rawTicketUrl : `https://${rawTicketUrl}`)
      : undefined;

    const hasExternalUrl = Boolean(
      normalizedTicketUrl &&
      extracted.source_platform &&
      extracted.source_platform.toLowerCase() !== 'vibe' &&
      extracted.source_platform.toLowerCase() !== 'telegram'
    );

    const finalSourceType: 'native' | 'external' = hasExternalUrl ? 'external' : 'native';
    const finalSourcePlatform = hasExternalUrl ? extracted.source_platform : undefined;
    const finalTicketUrl = hasExternalUrl ? normalizedTicketUrl : undefined;

    // If it's a Flash Vibe / Meetup, it is published immediately live to Vibe Instant!
    const isLiveImmediately = isFlashVibe;

    // Calculate event completeness and surety percentage
    const surety = calculateEventSurety({
      title: extracted.title,
      venue_name: extracted.venue_name,
      location_address: extracted.location_address,
      city: detectedCity,
      start_at: validStartAt,
      end_at: validEndAt,
      cover_image_url: coverImageUrl,
      price_text: extracted.price_text,
      description: extracted.description,
      date_inferred: extracted.date_inferred,
      time_inferred: extracted.time_inferred,
      venue_inferred: extracted.venue_inferred,
      city_inferred: extracted.city_inferred,
    });

    const suretyPercent = surety.score; // 0 to 100%
    const isAutoApproved = surety.autoApproved;
    const approvalStatus = isAutoApproved ? 'approved' : 'pending';
    const eventStatus = isAutoApproved ? 'live' : 'draft';
    const isPublic = isAutoApproved;

    // 3. Build Event Record for Supabase (only existing schema columns)
    const insertPayload = {
      slug: finalSlug,
      title: extracted.title || 'Untitled Gathering',
      tagline: extracted.tagline || `Experience the vibe in ${detectedCity}`,
      description:
        extracted.description ||
        `Join us for ${extracted.title || 'this event'} in ${detectedCity}. An exciting gathering bringing people together.`,
      cover_image_url: coverImageUrl,
      template: 'ember',
      theme: {
        palette: 'sunset',
        font: 'Inter',
        bg_style: 'solid',
        button_style: 'pill',
        confidence_score: suretyPercent / 100,
        missing_aspects: surety.missingAspects,
        approval_status: approvalStatus,
        admin_approved: isAutoApproved,
        date_inferred: extracted.date_inferred || false,
        venue_inferred: extracted.venue_inferred || false,
        city_inferred: extracted.city_inferred || false,
        is_flash: isFlashVibe,
        created_via: 'bot',
        source_platform: 'telegram',
        flash_activity: flashActivity,
        has_custom_poster: Boolean(isPhoto || isImageDoc),
      },
      sections: { speakers: false, agenda: false, gallery: false, faq: true },
      event_type: 'in-person',
      location_name: extracted.venue_name || `${detectedCity} Venue`,
      location_address: extracted.location_address || `${detectedCity}, India`,
      city: detectedCity,
      start_at: validStartAt,
      end_at: validEndAt,
      timezone: 'Asia/Kolkata',
      capacity: (extracted as any).capacity || (isFlashVibe ? 12 : 50),
      is_public: isPublic,
      status: eventStatus,
      ai_generated: true,
      source_type: 'bot',
      source_platform: 'telegram',
      external_ticket_url: finalTicketUrl,
      external_price_text: extracted.price_text || (hasExternalUrl ? 'See booking page' : 'Free Entry'),
      confidence_score: suretyPercent / 100,
      faq: extracted.faq || [],
      rsvp_form_config: {
        ask_plus_one: true,
        ask_dietary: false,
        ask_tshirt: false,
        waitlist_enabled: true,
        is_flash: true,
        confirmation_message: `You're confirmed for ${extracted.title || 'this flash meetup'}! Coordinate directly with other guests on Vibe.`,
      },
    };

    // 3.1 Duplicate Event Detection Guard (Requirement 4)
    const { isDuplicate, existingEvent } = await checkDuplicateEventInDb(supabase, {
      title: insertPayload.title,
      venue_name: insertPayload.location_name,
      city: insertPayload.city,
      start_at: insertPayload.start_at,
      ticket_url: insertPayload.external_ticket_url,
      slug: insertPayload.slug,
    });

    if (isDuplicate && existingEvent) {
      console.warn('[Telegram Webhook] 🛑 Duplicate event detected:', existingEvent.slug);
      const appUrl = getAppUrl(req);
      const existingLiveLink = `${appUrl}/${existingEvent.slug}`;
      const existingInstantLink = `${appUrl}/vibes?event=${encodeURIComponent(existingEvent.slug)}`;

      const duplicateWarning =
        `⚠️ <b>Duplicate Event Detected!</b>\n\n` +
        `An event matching <b>"${existingEvent.title}"</b> already exists on Vibe. We've restricted creating duplicate listings to keep the platform clean.\n\n` +
        `🔗 <b>Existing Event Link:</b>\n<a href="${existingLiveLink}">${existingLiveLink}</a>\n\n` +
        `⚡ <b>View in Vibe Instant:</b>\n<a href="${existingInstantLink}">${existingInstantLink}</a>\n\n` +
        `📋 <b>Tap to copy link:</b>\n<code>${existingLiveLink}</code>`;

      await replyTelegram(duplicateWarning, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🌐 View Existing Event ↗', url: existingLiveLink }],
            [{ text: '⚡ View in Vibe Instant ↗', url: existingInstantLink }],
          ],
        },
      });

      return NextResponse.json({
        ok: true,
        handledBy: 'duplicate_restricted',
        duplicate: true,
        existingEvent: {
          slug: existingEvent.slug,
          title: existingEvent.title,
        },
      });
    }

    const { data: savedEvent, error: insertError } = await supabase
      .from('events')
      .insert(insertPayload)
      .select('id, slug, title')
      .single();

    if (insertError || !savedEvent) {
      console.error('[Telegram Webhook] Insert error:', insertError);
      const safeErrorMsg = (insertError?.message || 'Unknown database error')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      await replyTelegram(
        `❌ <b>Failed to save event draft</b>: ${safeErrorMsg}`,
        { parse_mode: 'HTML' }
      );
      return NextResponse.json({ ok: true });
    }

    // Format friendly date string in IST
    const eventDate = new Date(insertPayload.start_at);
    const dateStr = eventDate.toLocaleDateString('en-IN', {
      timeZone: 'Asia/Kolkata',
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });

    const detectedCategory = (extracted.category || detectCategoryFromText(extracted.title)).toUpperCase();

    // 4. Send Confirmation Card with Inline Buttons to Telegram
    const appUrl = getAppUrl(req);
    const liveLink = `${appUrl}/${finalSlug}`;
    const instantLink = `${appUrl}/vibes?event=${finalSlug}`;
    const adminEventsUrl = `${appUrl}${ADMIN_BASE_PATH}`;

    let previewText: string;
    let inlineKeyboard: any[];

    const tgPoweredBySwaniki = `⚡ <b>Powered by <a href="https://swaniki.com/">SWANIKI</a></b>`;

    if (isAutoApproved) {
      if (isFlashVibe) {
        previewText = `🎉 <b>Your event is ready!</b>\n\n` +
          `⚡ <b>YOUR FLASH VIBE IS AUTO-APPROVED & LIVE!</b> (${suretyPercent}% Surety)\n\n` +
          `🔥 <b>${extracted.title}</b>\n` +
          `📍 ${extracted.venue_name || detectedCity} (${detectedCity})\n` +
          `🕒 ${dateStr} IST\n\n` +
          `✅ <i>Auto-Approved: All required details verified!</i>\n\n` +
          `🔗 <b>ACTUAL EVENT LINK:</b>\n<a href="${liveLink}">${liveLink}</a>\n\n` +
          `📱 <b>Vibe Instant Reel:</b>\n<a href="${instantLink}">${instantLink}</a>\n\n` +
          `📋 <b>Tap to copy link:</b>\n<code>${liveLink}</code>\n\n` +
          `📲 <i>Forward this link to your squad to invite friends!</i>\n\n` +
          tgPoweredBySwaniki;

        inlineKeyboard = [
          [{ text: '🌐 Open Event Link ↗', url: liveLink }],
          [{ text: '⚡ Open in Vibe Instant ↗', url: instantLink }],
          [{ text: '❌ Discard', callback_data: `discard:${savedEvent.id}` }],
        ];
      } else {
        previewText = `🎉 <b>Your event is ready!</b>\n\n` +
          `⚡ <b>EVENT AUTO-APPROVED & LIVE!</b> (${suretyPercent}% Surety)\n\n` +
          `📌 <b>Title:</b> ${extracted.title}\n` +
          `🏷️ <b>Category:</b> ${detectedCategory}\n` +
          `🗓️ <b>Date:</b> ${dateStr} IST\n` +
          `📍 <b>Venue:</b> ${extracted.venue_name} (${detectedCity})\n` +
          `💰 <b>Price:</b> ${extracted.price_text || (hasExternalUrl ? 'See booking page' : 'Free Entry')}\n` +
          `✅ <i>Auto-Approved: High completeness surety score.</i>\n\n` +
          `🔗 <b>ACTUAL EVENT LINK:</b>\n<a href="${liveLink}">${liveLink}</a>\n\n` +
          `📋 <b>Tap to copy link:</b>\n<code>${liveLink}</code>\n\n` +
          tgPoweredBySwaniki;

        inlineKeyboard = [
          [{ text: '🌐 Open Event Link ↗', url: liveLink }],
          [{ text: '⚡ View Reel in Instant ↗', url: instantLink }],
          [{ text: '❌ Discard', callback_data: `discard:${savedEvent.id}` }],
        ];
      }
    } else {
      const missingListFormatted = surety.missingAspects.length > 0
        ? surety.missingAspects.map(a => `🔴 <b>MISSING:</b> ${a}`).join('\n')
        : '🔴 <b>MISSING:</b> Specific venue place or start time not given';

      previewText = `🎉 <b>Your event draft is created!</b>\n\n` +
        `⏳ <b>EVENT SAVED AS DRAFT — REQUIRES DETAILS TO GO LIVE</b>\n\n` +
        `📌 <b>Title:</b> ${extracted.title}\n` +
        `🗓️ <b>Schedule:</b> ${dateStr} IST\n` +
        `📍 <b>Venue:</b> ${extracted.venue_name || 'Not given'} (${detectedCity})\n` +
        `💰 <b>Price:</b> ${extracted.price_text || (hasExternalUrl ? 'See booking page' : 'Free Entry')}\n\n` +
        `🚨 <b>CRITICAL DETAILS MISSING TO GO LIVE</b> 🔴\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `⚠️ <b>Current Surety: ${suretyPercent}%</b> (Requires <b>90%+</b> for instant listing)\n\n` +
        `${missingListFormatted}\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `📖 <b>USER GUIDE — HOW TO GO LIVE INSTANTLY:</b>\n` +
        `👉 <b>Text this bot again with the missing details above!</b>\n` +
        `<i>Example: /vibe ${extracted.title} at [Exact Venue], [Time], [Date]</i>\n\n` +
        `🔗 <b>ACTUAL EVENT LINK:</b>\n<a href="${liveLink}">${liveLink}</a>\n\n` +
        `📋 <b>Tap to copy link:</b>\n<code>${liveLink}</code>\n\n` +
        tgPoweredBySwaniki;

      inlineKeyboard = [
        [{ text: '🌐 Open Event Link ↗', url: liveLink }],
        [{ text: '⚡ Instant Publish to Live', callback_data: `publish:${savedEvent.id}` }],
        [{ text: '❌ Discard Draft', callback_data: `discard:${savedEvent.id}` }],
      ];
    }

    await replyTelegram(previewText, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: inlineKeyboard,
      },
    });

    return NextResponse.json({ ok: true });
  } catch (error: any) {
    console.error('[Telegram Webhook] Error:', error);
    try {
      if (update?.message?.chat?.id) {
        const threadId = update.message.message_thread_id;
        await sendTelegramMessage(
          update.message.chat.id,
          `⚠️ <b>Failed to process event:</b> ${error.message || 'Unknown processing error'}`,
          { parse_mode: 'HTML', ...(threadId ? { message_thread_id: threadId } : {}) }
        );
      }
    } catch (sendErr) {
      console.error('[Telegram Webhook] Failed to send error message to Telegram:', sendErr);
    }
    return NextResponse.json({ ok: true, error: error.message });
  }
}
